DATA FILES — "Creating Literary Network Data and Visualisations in Gephi"
=========================================================================

All references to flora and fauna in a genre-balanced selection of
Shakespeare's comedies and tragedies, categorised after Bessie Mayou's
"Natural History of Shakespeare" (1877). Character names use canonical
spellings (e.g. Mercutio, Petruchio, Ariel, Iachimo). UTF-8, comma-separated.

MASTER TABLE
------------
master_data.csv          1,016 rows — one per individual reference.
                         Columns: Main Topic, Sub-topic, Character, Play,
                         Genre, Gender, Status.
                         Every node/edge file below is derived from this table.

NODE / EDGE PAIRS (import the NODE file first, the EDGE file second)
--------------------------------------------------------------------
Each node file has columns: Id, Label, Type.
Each edge file has columns: Source, Target (no weights — duplicates are kept
so that Gephi's "Sum" merge strategy turns repeated rows into edge weights).

1) Main Topic – Character   (the worked example in the lesson)
   node_main-topic_character.csv   297 nodes (14 Main topic + 283 Character)
   edge_main-topic_character.csv   1,016 rows -> 650 weighted edges after Sum merge

2) Sub-topic – Character
   node_sub-topic_character.csv    569 nodes (286 Sub-topic + 283 Character)
   edge_sub-topic_character.csv    1,016 rows -> 947 weighted edges after Sum merge

3) Main Topic – Genre   (comedy / tragedy; called "Play Category" in some sheets)
   node_main-topic_genre.csv       16 nodes (14 Main topic + 2 Genre)
   edge_main-topic_genre.csv       1,016 rows -> 28 weighted edges after Sum merge

4) Main Topic – Gender
   node_main-topic_gender.csv      18 nodes (14 Main topic + 4 Gender)
   edge_main-topic_gender.csv      1,016 rows -> 40 weighted edges after Sum merge

IMPORT NOTES
------------
- Import the node file first, then the edge file.
- For the edge import, set Graph Type = Undirected and Edges merge strategy = Sum,
  and choose "Append to existing workspace".
- The import report shows the raw row count (e.g. 1,016); after the Sum merge the
  Context panel shows the weighted-edge count listed above.
